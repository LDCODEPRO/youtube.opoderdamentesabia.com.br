# 🎨 Briefing para o designer — Plataforma "Estúdio YouTube · O Poder da Mente Sábia"

**O que é:** painel de comando (web) do canal de YouTube "O Poder da Mente Sábia".
Está no ar em `youtube.opoderdamentesabia.com.br`. O dono quer o design MELHORADO
mantendo a identidade e as regras abaixo.

## O arquivo
- `index.html` — a plataforma inteira (CSS + HTML + JS num arquivo só).
- `logo.png` — o logo oficial da marca (lâmpada cromada com cérebro, fundo preto cósmico).
- `capas/video-02.png` — exemplo de thumbnail da marca (letras 3D cromadas).

Abra o `index.html` no navegador: você verá a tela de login; o painel interno
aparece nas seções `<div class="view">` (pode forçar exibindo `#painel` e
removendo a classe `hide` para trabalhar no layout).

## Identidade (INEGOCIÁVEL — é a marca)
- **Preto cósmico** de fundo: `#05060A`–`#090C10`, com campo de estrelas sutil e névoa fria.
- **Prata cromada** como acento: `#C9CDD8` (prata), `#F0F3FA` (branco-gelo). Glow frio `rgba(215,230,255,…)`.
- O logo (lâmpada-cérebro) é o coração visual — presente no login, na sidebar e no favicon.
- Semáforos de estado são à parte do acento: verde `#2EE6A8`, laranja `#FFA53D`, vermelho `#FF5D5D`.
- NADA de dourado (foi descartado pelo dono), nada de verde-marca, nada de colorido demais.

## As regras do dono (ele é rigoroso — seguir à risca)
1. **NUNCA usar linhas/listas horizontais nem tabelas cruas.** Tudo é CARD em grade.
2. **Cards com efeitos**: grafite com brilho radial no canto, borda acesa, glow, hover que
   levanta (`translateY(-3px)` + borda + glow forte), entrada em cascata.
3. **Número grande** é o herói do card; um assunto por card; cards pequenos e densos.
4. **MAIS VISUAL QUE TEXTO**: thumbnails, anéis de progresso, barras gordas, ícones grandes.
   Texto de apoio = 1 linha. Nada de parágrafos longos.
5. Linguagem 100% simples (zero jargão técnico) — os textos atuais já foram aprovados.
6. Painel largo esticado = feio. Grid de cards compactos = bonito.

## Cuidados técnicos (para não quebrar a plataforma)
- O JavaScript preenche o conteúdo pelos **IDs** (`#inscritos`, `#gridTarefas`, `#gridPautas`,
  `#gridPipeline`, `#gridLongos`, `#gridCortes`, `#gridCapas`, `#gridPesquisaResumo`,
  `#gridPesquisaTop`, `#gridProvasNossas`, `#anelMeta`, `#anelPct`, `#falaEstudio`, `#selo` etc.)
  e pelas **classes de componente** (`.card`, `.thumb`, `.ovl`, `.pill`, `.anel`, `.barraP`,
  `.tarefa`, `.view`, `nav.menu`). **Pode redesenhar o CSS à vontade; se mexer no HTML,
  preserve os IDs e as classes.**
- Single-file: manter tudo em um `index.html` (CSS no `<style>`, JS no `<script>`).
- As imagens dos vídeos vêm de `https://i.ytimg.com/...` em runtime; as capas de `/capas/...`.
- Tem que continuar bonito em celular (o layout atual colapsa a sidebar para o topo em ≤880px).
- Respeitar `prefers-reduced-motion` (já implementado — manter).

## O que o dono quer do designer
Elevar o nível visual (mais premium, mais "cockpit de cinema") SEM trair a identidade
preto+prata nem as regras acima. Referência de padrão que ele ama: cards do cockpit
do Agente X (grafite + glow ciano) — aqui é o mesmo espírito, com acento PRATA.
